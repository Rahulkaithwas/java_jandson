package day1to2;

/**
 * @author sumit kumar
 * @code 02-09
*/
public class HelloWorld {

	public static void main(String[] args) {
		
		System.out.println("Hello World");
	}

}
