package day1to2;

/**
 * @author sumit kumar
 * @code 02-09
 */
public class ProfitCalculation {

	public static void main(String[] args) {
		float buyingPrice = 20.54f;
		float sellingPrice = 30.50f;
		System.out.println(buyingPrice);
		System.out.println(sellingPrice);

	}

}
